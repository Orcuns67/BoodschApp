export class Todo {
    constructor(
        public id: number,
        public todoitem: string,
        public status:boolean
    )
    {}
}